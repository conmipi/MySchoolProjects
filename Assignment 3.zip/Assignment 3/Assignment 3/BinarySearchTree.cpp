#include<iostream>
#include<fstream>
#include <cstdlib>
using namespace std;

typedef struct {
	int num;
}NodeData;

typedef struct treeNode {
	NodeData data;
	struct treeNode *left, *right;
}TreeNode, *TreeNodePtr;

typedef struct {
	TreeNodePtr root;
}BinarySearchTree;

int arrOfInts[100];

int main() {
	int number;
	int counter = 0;
	int getInt(fstream *infile);
	TreeNodePtr newTreeNode(NodeData);
	NodeData newNodeData(int);
	TreeNodePtr findOrInsert(BinarySearchTree, NodeData);
	int searchAndCountArray(int[], int);
	int searchAndCountBinaryTree(BinarySearchTree, int);

	fstream infile;
	infile.open("integers.txt");
	if (infile.is_open() == false) { cout << "Can not open the file"; system("pause"); exit(1); }

	BinarySearchTree bst;
	bst.root = NULL;

	while (!infile.eof()) {
		number = getInt(&infile);
		arrOfInts[counter] = number;
		if (bst.root == NULL) {
			bst.root = newTreeNode(newNodeData(number));
		}

		else {
			TreeNodePtr node = findOrInsert(bst, newNodeData(number));

		}
		counter++;
	}

	infile.close();


	cout << searchAndCountBinaryTree(bst, 175)<< "\n";
	cout << "Done";
	system("pause");
}

int getInt(fstream * in) {
	int n;
	*in >> n;
	return n;
}

int searchAndCountArray(int arr[],int num) {
	int operationCount = 1;
	for (int i = 0; i < 100; i++) {
		if (arr[i] == num) {
			return operationCount;
		}
		operationCount++;
	}
	return 0;
}

int searchAndCountBinaryTree(BinarySearchTree bt, int num) {
	TreeNodePtr curr = bt.root;
	int operationCount = 1;
	if (curr->data.num == num) {
		return operationCount;
	}
	while (curr->left != NULL && curr->right != NULL) {
		if (curr->data.num > num) {
			curr = curr->left;
			operationCount++;
		}
		if(curr->data.num < num) {
			curr = curr->right;
			operationCount++;
		}
		if (curr->data.num == num) {
			return operationCount;
		}
	}
	return 0;
}

TreeNodePtr findOrInsert(BinarySearchTree bt, NodeData d) {
	TreeNodePtr newTreeNode(NodeData);
	if (bt.root == NULL) return newTreeNode(d);
	TreeNodePtr curr = bt.root;
		if (d.num < curr->data.num) { // if left
			if (curr->left == NULL) return curr->left = newTreeNode(d);
			curr = curr->left;
		}
		else { // try right
			if (curr->right == NULL) return curr->right = newTreeNode(d);
			curr = curr->right;
		}
		// d is in th tree; return pointer to the node
	return curr;
}

NodeData newNodeData(int n) {
	NodeData temp;
	temp.num = n;
	return temp;
}

TreeNodePtr newTreeNode(NodeData d) {
	TreeNodePtr p = new TreeNode;
	p->data = d;
	p->left = p->right = NULL;
	return p;
}